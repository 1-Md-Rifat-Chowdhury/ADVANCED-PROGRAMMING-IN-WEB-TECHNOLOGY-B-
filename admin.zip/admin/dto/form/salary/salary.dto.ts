import { IsEmail, IsNumber } from "class-validator";

export class SalaryDtoform
{

    @IsNumber()
    salary:string;

    @IsEmail()
    email:string;
    
}