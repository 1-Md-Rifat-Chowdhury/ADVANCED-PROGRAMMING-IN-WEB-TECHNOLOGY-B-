import { IsNotEmpty } from "class-validator";


export class TestDtoForm

{


    @IsNotEmpty()
    testName:string;

    @IsNotEmpty()
    testReasson:string;

    
}