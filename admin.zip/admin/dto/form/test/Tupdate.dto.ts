import { Length } from "class-validator";

export class TestDtoUpdate{


    @Length(8,20)
    testName:string;

}