import { IsDate, IsNotEmpty, IsTimeZone } from "class-validator";

export class EmergencyDtoForm
{


    @IsNotEmpty()
    caseof:string;

    @IsDate()
    date:string;
}