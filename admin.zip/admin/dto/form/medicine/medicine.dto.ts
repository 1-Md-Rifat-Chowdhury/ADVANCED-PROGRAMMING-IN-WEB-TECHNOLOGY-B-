import { IsNotEmpty, isNotEmpty } from "class-validator";

export class MedicineDtoForm
{



   @IsNotEmpty()
   MedicineName:string;

   
   @IsNotEmpty()
   MedicineGroup:string;

   
   @IsNotEmpty()
   MedicinePrice:string;



}