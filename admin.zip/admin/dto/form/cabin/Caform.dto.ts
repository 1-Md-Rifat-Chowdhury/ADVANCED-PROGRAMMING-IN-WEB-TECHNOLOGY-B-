import { IsNotEmpty } from "class-validator";


export class CabinDtoForm
{

@IsNotEmpty()
cabinNumber:string;


}