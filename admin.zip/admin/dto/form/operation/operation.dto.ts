import { IsNotEmpty } from "class-validator";

export class OperationDtoForm

{


    @IsNotEmpty()
    OpRoomNumber:string;
    
}