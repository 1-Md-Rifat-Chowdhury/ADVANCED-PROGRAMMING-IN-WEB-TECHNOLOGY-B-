import { IsDate, IsNotEmpty, IsNumber, IsTimeZone } from "class-validator";

export class AmbulenceDtoForm
{


    
    

    
    @IsDate()
    date:string;

    @IsTimeZone()
    time:string;


    @IsNumber()
    contact:number;

}