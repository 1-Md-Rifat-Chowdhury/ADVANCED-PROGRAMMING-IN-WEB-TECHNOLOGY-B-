import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";


@Entity()
export class SalaryEntity
{

    @PrimaryGeneratedColumn()
    SalId:number;

    @Column()
    salary:string;

    @Column()
    email:string;
}