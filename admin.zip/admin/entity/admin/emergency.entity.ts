import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class EmergencyEntity
{

    @PrimaryGeneratedColumn()
    Emid

    
    @Column()
    caseof:string;

    @Column()
    date:string;
}