import { Column, PrimaryGeneratedColumn } from "typeorm";


export class AmbulenceEntity
{

    @PrimaryGeneratedColumn()
    AmId

    @Column()
    date:string;


    @Column()
    time:string;

    @Column()
    contact:number;


    





}