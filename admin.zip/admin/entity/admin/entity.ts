import { DoctorEntity } from "src/doctor/entity/doctor/Dentity";
import { Entity,Column, PrimaryGeneratedColumn, OneToMany } from "typeorm";

@Entity('admin')
export class AdminEntity
{

    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    firstname:string;

    @Column()
    lastname:string;

    @Column()
    email:string;

    @Column()
    phoneNumber: string;

    @Column()
    passward: string;

    @Column()
    address:string;

    // @OneToMany(()  => DoctorEntity ,(doctor)=> doctor.admin)
    // doctor : DoctorEntity

}