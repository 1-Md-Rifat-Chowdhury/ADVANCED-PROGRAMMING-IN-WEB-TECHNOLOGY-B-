import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";


@Entity()
export class OperatiionEntity
{


    @PrimaryGeneratedColumn()
    OpId

    @Column()
    OpRoomNumber:string;
}