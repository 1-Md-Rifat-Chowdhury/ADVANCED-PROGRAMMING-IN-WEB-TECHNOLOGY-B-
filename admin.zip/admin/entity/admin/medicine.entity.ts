import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";


@Entity()
export class MedicineEntity
{
   @PrimaryGeneratedColumn()
   medicineId


   @Column()
   MedicineName:string;

   
   @Column()
   MedicineGroup:string;

   
   @Column()
   MedicinePrice:string;
}