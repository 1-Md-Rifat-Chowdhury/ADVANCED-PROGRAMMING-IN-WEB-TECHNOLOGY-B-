import { CanActivate } from "@nestjs/common";
import { Injectable } from "@nestjs/common";
import { ExecutionContext } from "@nestjs/common";
import { Observable } from "rxjs";


@Injectable()
export class SessionGuard implements CanActivate
{

    canActivate

        
        (context: ExecutionContext,): boolean | Promise<boolean> | Observable<boolean> 
        {
            {
                const request =context.switchToHttp().getRequest();
                return request.session.email !==undefined;
            
            }
        }
    
}